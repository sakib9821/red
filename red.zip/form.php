<?php
$email = $_POST['email'];
$number = $_POST['number'];
$message = $_POST['message'];

$conn=new mysqli('localhost','root','','redchilli');
if($conn->connect_error){
	echo "$conn->connect_error";
	die("connection Failed : ".$conn->connect_error);
} else{
  $stmt = $conn->prepare("insert into contact(email,number,message) values(?, ?, ?)");

  $stmt->bind_param("sis", $email, $number, $message);
  		$execval = $stmt->execute();
  		echo $execval;
  		echo"Message sent succesfully";
  		$stmt->close();
		$conn->close();
}

?>
