<?php
$email = $_POST['email'];
$number = $_POST['number'];
$message = $_POST['message'];


//$to = "anmsakib9821@gmail.com";
//$headers = "From: " .$email_from;
//$txt = "You have recieved an email from".$name."\n\n".$message;
//mail($to,$email_subject,$email_body,$headers);
//header("location: index.html");

$conn=new mysqli('localhost','root','','redchilli');
if($conn->connect_error){
	echo "$conn->connect_error";
	die("connection Failed : ".$conn->connect_error);
} else{
  $stmt = $conn->prepare("insert into contact(email,number,message) values(?, ?, ?)");

  $stmt->bind_param("sis", $email, $number, $message);
  		$execval = $stmt->execute();
  		echo $execval;
  		echo"Message sent succesfully";
  		$stmt->close();
		$conn->close();
}

?>
